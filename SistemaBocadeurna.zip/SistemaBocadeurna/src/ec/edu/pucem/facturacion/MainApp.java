package ec.edu.pucem.facturacion;

import ec.edu.pucem.facturacion.formulario.FrmMenuPrincipal;

public class MainApp {

	public static void main(String[] args) {
		FrmMenuPrincipal formulario=new FrmMenuPrincipal();
		formulario.setVisible(true);
	}

}
