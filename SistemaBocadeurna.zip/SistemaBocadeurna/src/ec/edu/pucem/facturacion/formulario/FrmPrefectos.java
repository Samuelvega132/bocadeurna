package ec.edu.pucem.facturacion.formulario;


import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import ec.edu.pucem.facturacion.dominio.ListaPrefectos;
import ec.edu.pucem.facturacion.dominio.Prefecto;

import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FrmPrefectos extends JInternalFrame {

    private static final long serialVersionUID = 1L;
    private JTextField textFieldNombre;
    private JTextField textFieldPartido;
    private ListaPrefectos listaPrefectos;

    public FrmPrefectos(ListaPrefectos listaPrefectos) {
        this.listaPrefectos = listaPrefectos;
        setTitle("Crear Prefecto");
        setClosable(true);
        setBounds(100, 100, 450, 300);
        getContentPane().setLayout(null);
        
        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setBounds(30, 30, 80, 25);
        getContentPane().add(lblNombre);
        
        textFieldNombre = new JTextField();
        textFieldNombre.setBounds(120, 30, 200, 25);
        getContentPane().add(textFieldNombre);
        textFieldNombre.setColumns(10);
        
        JLabel lblPartido = new JLabel("Partido:");
        lblPartido.setBounds(30, 70, 80, 25);
        getContentPane().add(lblPartido);
        
        textFieldPartido = new JTextField();
        textFieldPartido.setBounds(120, 70, 200, 25);
        getContentPane().add(textFieldPartido);
        textFieldPartido.setColumns(10);
        
        JButton btnGuardar = new JButton("Guardar");
        btnGuardar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String nombre = textFieldNombre.getText();
                String partido = textFieldPartido.getText();
                Prefecto prefecto = new Prefecto(nombre, partido);
                listaPrefectos.agregarPrefecto(prefecto);
            }
        });
        btnGuardar.setBounds(120, 120, 100, 25);
        getContentPane().add(btnGuardar);
    }
}
