package ec.edu.pucem.facturacion.formulario;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import ec.edu.pucem.facturacion.dominio.ListaPrefectos;
import ec.edu.pucem.facturacion.dominio.ListaVotos;
import ec.edu.pucem.facturacion.dominio.Prefecto;
import ec.edu.pucem.facturacion.dominio.Voto;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FrmBocaDeUrna extends JInternalFrame {

    private static final long serialVersionUID = 1L;
    private JTextField textFieldCantidadVotos;
    private JTextField textFieldCiudad;
    private ListaVotos listaVotos;
    private ListaPrefectos listaPrefectos;
    private JComboBox<String> comboBoxPrefectos;

    public FrmBocaDeUrna(ListaVotos listaVotos, ListaPrefectos listaPrefectos) {
        this.listaVotos = listaVotos;
        this.listaPrefectos = listaPrefectos;
        setTitle("Boca de Urna");
        setClosable(true);
        setBounds(100, 100, 450, 300);
        getContentPane().setLayout(null);
        
        JLabel lblCiudad = new JLabel("Ciudad:");
        lblCiudad.setBounds(30, 30, 80, 25);
        getContentPane().add(lblCiudad);
        
        textFieldCiudad = new JTextField();
        textFieldCiudad.setBounds(120, 30, 200, 25);
        getContentPane().add(textFieldCiudad);
        textFieldCiudad.setColumns(10);
        
        JLabel lblPrefecto = new JLabel("Prefecto:");
        lblPrefecto.setBounds(30, 70, 80, 25);
        getContentPane().add(lblPrefecto);
        
        comboBoxPrefectos = new JComboBox<>();
        comboBoxPrefectos.setBounds(120, 70, 200, 25);
        for (Prefecto prefecto : listaPrefectos.getPrefectos()) {
            comboBoxPrefectos.addItem(prefecto.getNombre());
        }
        getContentPane().add(comboBoxPrefectos);
        
        JLabel lblCantidadVotos = new JLabel("Cantidad de Votos:");
        lblCantidadVotos.setBounds(30, 110, 140, 25);
        getContentPane().add(lblCantidadVotos);
        
        textFieldCantidadVotos = new JTextField();
        textFieldCantidadVotos.setBounds(180, 110, 140, 25);
        getContentPane().add(textFieldCantidadVotos);
        textFieldCantidadVotos.setColumns(10);
        
        JButton btnGuardar = new JButton("Guardar");
        btnGuardar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String ciudad = textFieldCiudad.getText();
                String nombrePrefecto = (String) comboBoxPrefectos.getSelectedItem();
                int cantidadVotos = Integer.parseInt(textFieldCantidadVotos.getText());
                Prefecto prefecto = listaPrefectos.getPrefectoByName(nombrePrefecto);
                if (prefecto != null) {
                    Voto voto = new Voto(ciudad, prefecto, cantidadVotos);
                    listaVotos.agregarVoto(voto);
                    comboBoxPrefectos.removeItem(nombrePrefecto);  // Remove candidate after voting
                }
            }
        });
        btnGuardar.setBounds(120, 160, 100, 25);
        getContentPane().add(btnGuardar);
    }
}
