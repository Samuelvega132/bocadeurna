package ec.edu.pucem.facturacion.dominio;

public class Voto {

    private String ciudad;
    private Prefecto prefecto;
    private int cantidadVotos;

    public Voto(String ciudad, Prefecto prefecto, int cantidadVotos) {
        this.ciudad = ciudad;
        this.prefecto = prefecto;
        this.cantidadVotos = cantidadVotos;
    }

    public String getCiudad() {
        return ciudad;
    }

    public Prefecto getPrefecto() {
        return prefecto;
    }

    public int getCantidadVotos() {
        return cantidadVotos;
    }
}
