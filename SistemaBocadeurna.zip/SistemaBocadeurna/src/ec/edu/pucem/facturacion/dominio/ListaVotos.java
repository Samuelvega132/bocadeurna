package ec.edu.pucem.facturacion.dominio;

import java.util.ArrayList;
import java.util.List;

import java.util.ArrayList;
import java.util.List;

import java.util.ArrayList;
import java.util.List;

import java.util.ArrayList;

public class ListaVotos {
    private ArrayList<Voto> votos;

    public ListaVotos() {
        this.votos = new ArrayList<>();
    }

    public void agregarVoto(Voto voto) {
        this.votos.add(voto);
    }

    public ArrayList<Voto> getVotos() {
        return votos;
    }
}
